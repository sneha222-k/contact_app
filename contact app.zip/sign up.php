<?php
$Firstname = filter_input(INPUT_POST, 'Firstname');
$Lastname = filter_input(INPUT_POST, 'Lastname');
$email = filter_input(INPUT_POST, 'email');
$password = filter_input(INPUT_POST, 'password');
$repeatpass = filter_input(INPUT_POST, 'repeatpass');

//database connection
$servername = "localhost";
$email = "";
$password = "";
$dbname = "test";
$conn = new mysqli($servername,$email, $password, $dbname);

if(mysqli_connect_error()){
	die('connect_error('.mysqli_connect_error().')'
		.mysqli_connect_error());
}
else{
	$sql = "INSERT INTO login(email,password)
	values ('$email','$password')";
	if($conn->query($sql)){
		echo "registered successfully";
	}
	else{
		echo "error";
	}
	$conn->close();
}
?>