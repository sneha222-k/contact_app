<?php
    $email = $_POST['email'];
    $password = $_POST['password'];
    $number = $_POST['number'];


//Database connection
$conn = new mysqli('localhost','root','','test');
if($conn->connect_error){
    die('Connection Failed : '.$conn->connect_error);
}else{
    $stmt=$conn->prepare("insert into login(email,password,number) values(?,?,?)");
    $stmt->bind_param("ssi",$email,$password,$number);
    $stmt->execute();
    echo "saved successful...";
    $stmt->close();
    $conn->close();
}
?>