<?php
	$email = $_POST['Firstname'];
	$password = $_POST['Lastname'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$password = $_POST['repeatpass'];


//Database connection
$conn = new mysqli('localhost','root','','test');
if($conn->connect_error){
	die('Connection Failed : '.$conn->connect_error);
}else{
	$stmt=$conn->prepare("insert into login(Firstname,Lastname,email,password,repeatpass) values(?,?,?,?,?)");
	$stmt->bind_param("sssss",$Firstname,$Lastname,$email,$password,$repeatpass);
	$stmt->execute();
	echo "registered successful...";
	$stmt->close();
	$conn->close();
}
?>